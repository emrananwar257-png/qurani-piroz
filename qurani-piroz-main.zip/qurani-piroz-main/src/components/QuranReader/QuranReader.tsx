import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

const PAGE_COUNT = 604;
const AYAH_CANVAS_WIDTH = 1260;
const AYAH_CANVAS_HEIGHT = 2020;

const QURAN_PAGE_BASE =
  'https://android.quran.com/data/width_1260/';

const QURAN_API_BASE =
  'https://api.alquran.cloud/v1';

const MP3QURAN_API_BASE =
  'https://mp3quran.net/api/v3';

const RIZGAR_RECITER_ID = 'rizgar_kurdi';
const RIZGAR_AUDIO_BASE =
  'https://github.com/Hiwaselah/qari_kurdi_mutasil/releases/download/rzgar_kurdi_mutasil/';
const RIZGAR_TIMING_BASE = '/ayah-timings/rizgar_kurdi';

const RECITERS_CACHE_KEY =
  'quran_dynamic_kurdish_reciters_v2';

const TIMING_CACHE_KEY =
  'quran_mp3quran_timing_v2';

interface AyahData {
  number?: number;
  ayah?: number;
  globalAyah?: number;
  text?: string;
  surahNumber?: number;
  [key: string]: unknown;
}

interface TimingRow {
  ayah: number;
  start: number;
  end: number;
}

interface DynamicReciter {
  id: string;
  sourceId: string;
  name: string;
  nameAr?: string;
  riwayah: string;
  server: string;
  surahList: number[];
  surahTotal: number;
  moshafId: string;
  source: 'mp3quran' | 'direct';
}

interface SurahItem {
  number?: number;
  id?: number;
  name?: string;
  englishName?: string;
  startPage?: number;
  page?: number;
  endPage?: number;
  [key: string]: unknown;
}

interface QuranReaderProps {
  currentPage: number;
  onNextPage: () => void;
  onPrevPage: () => void;
  onBackToIndex: () => void;
  bgStyle?: React.CSSProperties;
  appLang: string;
  showNumbers: boolean;
  surahsList?: SurahItem[];
  onJumpToPage?: (page: number) => void;
}

interface Mp3Reciter {
  id?: number | string;
  name?: string;
  letter?: string;
  moshaf?: Array<{
    id?: number | string;
    name?: string;
    server?: string;
    surah_total?: number | string;
    surah_list?: string;
    moshaf_type?: number | string;
  }>;
}

const KURDISH_RECITER_ALIASES: Array<{
  id: string;
  aliases: string[];
  kurdishName: string;
}> = [
  {
    id: 'peshawa_kurdi',
    aliases: [
      'peshawa qadr al-kurdi',
      'peshawa kurdi',
      'peshawa',
      'بيشة وا قادر الكردي',
      'بيشةوا قادر الكردي',
    ],
    kurdishName: 'پێشەوا قادر کوردی',
  },
  {
    id: 'raad_kurdi',
    aliases: [
      'raad al kurdi',
      'raad al-kurdi',
      'raad kurdi',
      'رعد محمد الكردي',
      'رعد الكردي',
    ],
    kurdishName: 'ڕەعد کوردی',
  },
  {
    id: 'ramadan_shakoor',
    aliases: [
      'ramadan shakoor',
      'ramadan shakur',
      'رمضان شكور',
    ],
    kurdishName: 'ڕەمەزان شاکور',
  },
  {
    id: 'shirazad_taher',
    aliases: [
      'shirazad taher',
      'shirzad taher',
      'شيرزاد عبدالرحمن طاهر',
      'شيرزاد طاهر',
    ],
    kurdishName: 'شێرزاد تاهر',
  },
  {
    id: 'wishear_hayder_arbili',
    aliases: [
      'wishear hayder arbili',
      'wishear haydar arbili',
      'وشيار حيدر اربيلي',
      'وشيار حيدر أربيلي',
    ],
    kurdishName: 'ویشیار حەیدەر ئەربیلی',
  },
];

const normalizeText = (value: unknown): string =>
  String(value ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[’']/g, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const normalizeUrl = (url: string): string =>
  url.endsWith('/') ? url : `${url}/`;

const parseSurahList = (value: unknown): number[] => {
  if (typeof value !== 'string') return [];

  return value
    .split(',')
    .map((item) => Number(item.trim()))
    .filter(
      (item) =>
        Number.isInteger(item) &&
        item >= 1 &&
        item <= 114,
    );
};

const readJsonCache = <T,>(
  key: string,
): T | null => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
};

const writeJsonCache = (
  key: string,
  value: unknown,
) => {
  try {
    localStorage.setItem(
      key,
      JSON.stringify(value),
    );
  } catch {
    // Ignore storage errors.
  }
};

const formatPageNum = (page: number): string =>
  String(page).padStart(3, '0');

const pageImgUrl = (page: number): string =>
  `${QURAN_PAGE_BASE}page${formatPageNum(page)}.png`;

const normalizeTimingValue = (
  value: unknown,
): number => {
  const n = Number(value);

  if (!Number.isFinite(n) || n < 0) {
    return 0;
  }

  return n > 10000 ? n / 1000 : n;
};

const getPageSurahNumber = (
  page: number,
  surahsList?: SurahItem[],
): number => {
  if (!surahsList?.length) {
    return 1;
  }

  const normalized = surahsList
    .map((surah) => ({
      number: Number(surah.number ?? surah.id ?? 0),
      startPage: Number(
        surah.startPage ??
          surah.page ??
          surah['start_page'] ??
          0,
      ),
      endPage: Number(
        surah.endPage ??
          surah['end_page'] ??
          0,
      ),
    }))
    .filter(
      (surah) =>
        surah.number >= 1 &&
        surah.number <= 114 &&
        surah.startPage > 0,
    )
    .sort(
      (a, b) =>
        a.startPage - b.startPage,
    );

  const inRange = normalized.find(
    (surah) =>
      page >= surah.startPage &&
      (!surah.endPage ||
        page <= surah.endPage),
  );

  if (inRange) {
    return inRange.number;
  }

  let result = normalized[0]?.number ?? 1;

  for (const surah of normalized) {
    if (surah.startPage <= page) {
      result = surah.number;
    } else {
      break;
    }
  }

  return result;
};

const findKurdishAlias = (
  name: string,
) => {
  const normalized = normalizeText(name);

  return KURDISH_RECITER_ALIASES.find(
    (entry) =>
      entry.aliases.some(
        (alias) =>
          normalized === normalizeText(alias) ||
          normalized.includes(
            normalizeText(alias),
          ) ||
          normalizeText(alias).includes(
            normalized,
          ),
      ),
  );
};

const chooseBestMoshaf = (
  moshaf: Mp3Reciter['moshaf'],
) => {
  if (!Array.isArray(moshaf)) {
    return null;
  }

  const usable = moshaf
    .filter(
      (item) =>
        item?.server &&
        parseSurahList(
          item?.surah_list,
        ).length > 0,
    )
    .sort((a, b) => {
      const aCount =
        parseSurahList(
          a?.surah_list,
        ).length;

      const bCount =
        parseSurahList(
          b?.surah_list,
        ).length;

      return bCount - aCount;
    });

  return usable[0] ?? null;
};

const makeRizgarReciter = (): DynamicReciter => ({
  id: RIZGAR_RECITER_ID,
  sourceId: RIZGAR_RECITER_ID,
  name: 'ڕزگار محەمەد کوردی',
  nameAr: 'Rizgar Muhammad Kurdi',
  riwayah: 'حفص',
  server: RIZGAR_AUDIO_BASE,
  surahList: Array.from({ length: 114 }, (_, index) => index + 1),
  surahTotal: 114,
  moshafId: RIZGAR_RECITER_ID,
  source: 'direct',
});

async function fetchRizgarTiming(
  surahNumber: number,
): Promise<TimingRow[]> {
  try {
    const response = await fetch(
      RIZGAR_TIMING_BASE + '/' + surahNumber + '.json',
      { cache: 'no-store' },
    );
    if (!response.ok) return [];

    const json = await response.json();
    const rows = Array.isArray(json)
      ? json
      : Array.isArray(json?.timing)
        ? json.timing
        : Array.isArray(json?.ayahs)
          ? json.ayahs
          : Array.isArray(json?.data)
            ? json.data
            : [];

    return rows
      .map((row: any, index: number) => ({
        ayah: Number(row?.ayah ?? row?.ayah_number ?? row?.number ?? index + 1),
        start: normalizeTimingValue(row?.start_time ?? row?.start ?? 0),
        end: normalizeTimingValue(row?.end_time ?? row?.end ?? 0),
      }))
      .filter(
        (row: TimingRow) =>
          Number.isFinite(row.ayah) &&
          row.ayah >= 1 &&
          row.end >= row.start,
      );
  } catch {
    return [];
  }
}

async function fetchDynamicKurdishReciters(): Promise<
  DynamicReciter[]
> {
  const response = await fetch(
    `${MP3QURAN_API_BASE}/reciters?language=eng`,
    {
      cache: 'no-store',
    },
  );

  if (!response.ok) {
    throw new Error(
      `MP3Quran reciters API: ${response.status}`,
    );
  }

  const json = await response.json();

  const reciters: Mp3Reciter[] =
    Array.isArray(json)
      ? json
      : Array.isArray(json?.reciters)
        ? json.reciters
        : Array.isArray(json?.data)
          ? json.data
          : [];

  const result: DynamicReciter[] = [makeRizgarReciter()];

  for (const reciter of reciters) {
    if (findKurdishAlias(String(reciter?.name ?? ''))?.id === RIZGAR_RECITER_ID) continue;

    const name = String(
      reciter?.name ?? '',
    ).trim();

    if (!name) continue;

    const alias = findKurdishAlias(name);

    if (!alias) continue;

    const moshaf =
      chooseBestMoshaf(
        reciter?.moshaf,
      );

    if (!moshaf?.server) continue;

    const surahList = parseSurahList(
      moshaf.surah_list,
    );

    if (!surahList.length) continue;

    result.push({
      id: alias.id,
      sourceId: String(
        reciter.id ?? alias.id,
      ),
      name: alias.kurdishName,
      nameAr: name,
      riwayah: 'حفص',
      server: normalizeUrl(
        String(moshaf.server),
      ),
      surahList,
      surahTotal: surahList.length,
      moshafId: String(
        moshaf.id ??
          reciter.id ??
          alias.id,
      ),
      source: 'mp3quran',
    });
  }

  const unique = new Map<
    string,
    DynamicReciter
  >();

  for (const item of result) {
    const old = unique.get(item.id);

    if (
      !old ||
      item.surahTotal > old.surahTotal
    ) {
      unique.set(item.id, item);
    }
  }

  const ordered = KURDISH_RECITER_ALIASES
    .map((alias) =>
      unique.get(alias.id),
    )
    .filter(
      (
        item,
      ): item is DynamicReciter =>
        Boolean(item),
    );

  if (!ordered.length) {
    throw new Error(
      'هیچ قارییەکی کورد لە MP3Quran نەدۆزرایەوە.',
    );
  }

  writeJsonCache(
    RECITERS_CACHE_KEY,
    ordered,
  );

  return ordered;
}

async function fetchPageAyahs(
  page: number,
): Promise<AyahData[]> {
  const response = await fetch(
    `${QURAN_API_BASE}/page/${page}/editions/quran-uthmani`,
    {
      cache: 'force-cache',
    },
  );

  if (!response.ok) {
    throw new Error(
      `Quran text API: ${response.status}`,
    );
  }

  const json = await response.json();

  const edition = Array.isArray(
    json?.data,
  )
    ? json.data[0]
    : json?.data;

  const ayahs = Array.isArray(
    edition?.ayahs,
  )
    ? edition.ayahs
    : [];

  return ayahs.map(
    (ayah: any) => ({
      ...ayah,
      globalAyah: Number(
        ayah?.number ?? 0,
      ),
      ayah: Number(
        ayah?.numberInSurah ??
          ayah?.ayah ??
          0,
      ),
    }),
  );
}

async function fetchMp3QuranTiming(
  readId: string,
  surahNumber: number,
): Promise<TimingRow[]> {
  const cacheKey =
    `${TIMING_CACHE_KEY}:${readId}:${surahNumber}`;

  const cached =
    readJsonCache<TimingRow[]>(
      cacheKey,
    );

  if (
    Array.isArray(cached) &&
    cached.length
  ) {
    return cached;
  }

  const url =
    `${MP3QURAN_API_BASE}/ayat_timing` +
    `?surah=${encodeURIComponent(
      String(surahNumber),
    )}` +
    `&read=${encodeURIComponent(
      String(readId),
    )}`;

  const response = await fetch(
    url,
    {
      cache: 'force-cache',
    },
  );

  if (!response.ok) {
    throw new Error(
      `MP3Quran timing API: ${response.status}`,
    );
  }

  const json = await response.json();

  const rows = Array.isArray(json)
    ? json
    : Array.isArray(json?.ayat)
      ? json.ayat
      : Array.isArray(json?.data)
        ? json.data
        : Array.isArray(json?.timing)
          ? json.timing
          : Array.isArray(json?.ayahs)
            ? json.ayahs
            : [];

  const timings: TimingRow[] =
    rows
      .map(
        (row: any, index: number) => ({
          ayah: Number(
            row?.ayah ??
              row?.ayah_number ??
              row?.number ??
              index + 1,
          ),
          start:
            normalizeTimingValue(
              row?.start_time ??
                row?.start ??
                0,
            ),
          end:
            normalizeTimingValue(
              row?.end_time ??
                row?.end ??
                0,
            ),
        }),
      )
      .filter(
        (row: TimingRow) =>
          Number.isFinite(row.ayah) &&
          row.ayah >= 1 &&
          row.end >= row.start,
      );

  if (timings.length) {
    writeJsonCache(
      cacheKey,
      timings,
    );
  }

  return timings;
}

const makeSurahAudioUrl = (
  reciter: DynamicReciter,
  surahNumber: number,
): string =>
  `${normalizeUrl(
    reciter.server,
  )}${String(surahNumber).padStart(
    3,
    '0',
  )}.mp3`;

const getInitialReciter = (
  reciters: DynamicReciter[],
): DynamicReciter | null => {
  try {
    const saved =
      localStorage.getItem(
        'quran_selected_reciter',
      );

    if (saved) {
      const found =
        reciters.find(
          (reciter) =>
            reciter.id === saved,
        );

      if (found) return found;
    }
  } catch {
    // Ignore storage errors.
  }

  return reciters[0] ?? null;
};

export function QuranReader({
  currentPage,
  onNextPage,
  onPrevPage,
  onBackToIndex,
  bgStyle,
  appLang,
  showNumbers,
  surahsList,
  onJumpToPage,
}: QuranReaderProps) {
  const audioRef =
    useRef<HTMLAudioElement | null>(
      null,
    );

  const pagesRef =
    useRef<HTMLDivElement | null>(
      null,
    );

  const timingCacheRef =
    useRef(
      new Map<
        string,
        TimingRow[]
      >(),
    );

  const loadingPlayRef =
    useRef(false);

  const activeTimingRef =
    useRef<TimingRow | null>(null);

  const playRequestRef =
    useRef(0);

  const [reciters, setReciters] =
    useState<DynamicReciter[]>(() => {
      return (
        readJsonCache<
          DynamicReciter[]
        >(RECITERS_CACHE_KEY) ?? []
      );
    });

  const [selectedReciter, setSelectedReciter] =
    useState<DynamicReciter | null>(
      () => {
        const cached =
          readJsonCache<
            DynamicReciter[]
          >(RECITERS_CACHE_KEY) ??
          [];

        return getInitialReciter(
          cached,
        );
      },
    );

  const [ayahs, setAyahs] =
    useState<AyahData[]>([]);

  const [
    playingAyahIndex,
    setPlayingAyahIndex,
  ] = useState<number | null>(
    null,
  );

  const [isPlaying, setIsPlaying] =
    useState(false);

  const [isLoading, setIsLoading] =
    useState(false);

  const [error, setError] =
    useState<string | null>(null);

  const [
    timingRows,
    setTimingRows,
  ] = useState<TimingRow[]>([]);

  const [
    selectedSurahNumber,
    setSelectedSurahNumber,
  ] = useState<number>(
    getPageSurahNumber(
      currentPage,
      surahsList,
    ),
  );

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      try {
        const fresh =
          await fetchDynamicKurdishReciters();

        if (cancelled) return;

        setReciters(fresh);

        setSelectedReciter(
          (old) => {
            if (!old) {
              return getInitialReciter(
                fresh,
              );
            }

            return (
              fresh.find(
                (item) =>
                  item.id === old.id,
              ) ??
              getInitialReciter(fresh)
            );
          },
        );
      } catch (err) {
        if (cancelled) return;

        const cached =
          readJsonCache<
            DynamicReciter[]
          >(RECITERS_CACHE_KEY);

        if (
          Array.isArray(cached) &&
          cached.length
        ) {
          setReciters(cached);
          setSelectedReciter(
            (old) =>
              old ??
              getInitialReciter(
                cached,
              ),
          );
          return;
        }

        setError(
          err instanceof Error
            ? err.message
            : 'کێشە لە هێنانی قارییەکان.',
        );
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    setSelectedSurahNumber(
      getPageSurahNumber(
        currentPage,
        surahsList,
      ),
    );
  }, [
    currentPage,
    surahsList,
  ]);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      try {
        setError(null);

        const data =
          await fetchPageAyahs(
            currentPage,
          );

        if (cancelled) return;

        setAyahs(data);
      } catch (err) {
        if (cancelled) return;

        setAyahs([]);

        setError(
          err instanceof Error
            ? err.message
            : 'دەقی لاپەڕەکە نەهێنرا.',
        );
      }
    };

    load();

    return () => {
      cancelled = true;
    };
  }, [currentPage]);

  useEffect(() => {
    const audio =
      audioRef.current;

    ++playRequestRef.current;
    activeTimingRef.current = null;
    loadingPlayRef.current = false;

    if (audio) {
      audio.pause();
      audio.removeAttribute('src');
      audio.load();
    }

    setPlayingAyahIndex(null);
    setIsPlaying(false);
    setIsLoading(false);
    setTimingRows([]);
  }, [
    currentPage,
    selectedReciter?.id,
  ]);

  useEffect(() => {
    if (!selectedReciter) return;

    try {
      localStorage.setItem(
        'quran_selected_reciter',
        selectedReciter.id,
      );
    } catch {
      // Ignore storage errors.
    }

    window.dispatchEvent(
      new CustomEvent(
        'quran-reciter-changed',
        {
          detail: {
            reciter:
              selectedReciter.id,
          },
        },
      ),
    );
  }, [selectedReciter]);

  useEffect(() => {
    return () => {
      ++playRequestRef.current;
      activeTimingRef.current = null;
      const audio = audioRef.current;
      if (audio) {
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
      }
    };
  }, []);

  const availableForCurrentSurah =
    useMemo(() => {
      if (!selectedReciter) {
        return false;
      }

      return selectedReciter.surahList.includes(
        selectedSurahNumber,
      );
    }, [
      selectedReciter,
      selectedSurahNumber,
    ]);

  const timingForCurrentSurah =
    useCallback(
      async (
        reciter: DynamicReciter,
        surahNumber: number,
      ) => {
        const key =
          `${reciter.moshafId}:${surahNumber}`;

        const local =
          timingCacheRef.current.get(
            key,
          );

        if (local) {
          return local;
        }

        const rows =
          reciter.id === RIZGAR_RECITER_ID
            ? await fetchRizgarTiming(surahNumber)
            : await fetchMp3QuranTiming(
                reciter.moshafId,
                surahNumber,
              );

        timingCacheRef.current.set(
          key,
          rows,
        );

        return rows;
      },
      [],
    );

  const getCurrentPageAyahIndex =
    useCallback(
      (
        audioTime: number,
        rows: TimingRow[],
        pageAyahs: AyahData[],
      ) => {
        if (
          !rows.length ||
          !pageAyahs.length
        ) {
          return -1;
        }

        const localAyahNumbers =
          pageAyahs.map((ayah, index) =>
            Number(
              ayah?.ayah ??
                ayah?.numberInSurah ??
                index + 1,
            ),
          );

        for (
          let i = 0;
          i < localAyahNumbers.length;
          i += 1
        ) {
          const ayahNumber =
            localAyahNumbers[i];

          const timing =
            rows.find(
              (row) =>
                row.ayah ===
                ayahNumber,
            );

          if (!timing) continue;

          if (
            audioTime >=
              timing.start &&
            audioTime <=
              Math.max(
                timing.end,
                timing.start + 0.15,
              )
          ) {
            return i;
          }
        }

        return -1;
      },
      [],
    );

  const waitForMetadata =
    useCallback(
      (audio: HTMLAudioElement) =>
        new Promise<void>((resolve, reject) => {
          if (
            Number.isFinite(audio.duration) &&
            audio.readyState >= 1
          ) {
            resolve();
            return;
          }

          let finished = false;

          const cleanup = () => {
            audio.removeEventListener(
              'loadedmetadata',
              done,
            );
            audio.removeEventListener(
              'error',
              failed,
            );
            window.clearTimeout(timer);
          };

          const done = () => {
            if (finished) return;
            finished = true;
            cleanup();
            resolve();
          };

          const failed = () => {
            if (finished) return;
            finished = true;
            cleanup();
            reject(
              new Error(
                'فایلی دەنگییەکە نەکرا بار بکرێت.',
              ),
            );
          };

          const timer = window.setTimeout(() => {
            if (finished) return;
            finished = true;
            cleanup();
            reject(
              new Error(
                'بارکردنی فایلی دەنگی زۆر درێژ بوو.',
              ),
            );
          }, 10000);

          audio.addEventListener(
            'loadedmetadata',
            done,
            { once: true },
          );
          audio.addEventListener(
            'error',
            failed,
            { once: true },
          );
        }),
      [],
    );

  const announceAudioPlaying =
    useCallback((audio: HTMLAudioElement) => {
      window.dispatchEvent(
        new CustomEvent<HTMLAudioElement>(
          'quran-audio-playing',
          { detail: audio },
        ),
      );
    }, []);

  useEffect(() => {
    const handleOtherAudio = (event: Event) => {
      const otherAudio =
        (event as CustomEvent<HTMLAudioElement>)
          .detail;
      const audio = audioRef.current;

      if (!audio || otherAudio === audio) return;

      audio.pause();
      setIsPlaying(false);
      setPlayingAyahIndex(null);
      activeTimingRef.current = null;
    };

    window.addEventListener(
      'quran-audio-playing',
      handleOtherAudio,
    );

    return () => {
      window.removeEventListener(
        'quran-audio-playing',
        handleOtherAudio,
      );
    };
  }, []);

  const playAyah =
    useCallback(
      async (index: number) => {
        if (
          !selectedReciter ||
          !ayahs[index]
        ) {
          return;
        }

        const surahNumber =
          selectedSurahNumber;

        if (
          !selectedReciter.surahList.includes(
            surahNumber,
          )
        ) {
          setError(
            `ئەم سۆرەتە لەلایەن ${selectedReciter.name} بەردەست نییە.`,
          );
          return;
        }

        const audio = audioRef.current;
        if (!audio) return;

        const requestId =
          ++playRequestRef.current;

        loadingPlayRef.current = true;
        setIsLoading(true);
        setError(null);

        activeTimingRef.current = null;
        setPlayingAyahIndex(null);
        setIsPlaying(false);
        audio.pause();

        try {
          const rows =
            await timingForCurrentSurah(
              selectedReciter,
              surahNumber,
            );

          if (requestId !== playRequestRef.current) {
            return;
          }

          const ayahNumber = Number(
            ayahs[index]?.ayah ??
              ayahs[index]?.numberInSurah ??
              index + 1,
          );

          const timing = rows.find(
            (row) => row.ayah === ayahNumber,
          );

          setTimingRows(rows);

          const src = makeSurahAudioUrl(
            selectedReciter,
            surahNumber,
          );

          if (audio.src !== src) {
            audio.src = src;
            audio.load();
          }

          await waitForMetadata(audio);

          if (requestId !== playRequestRef.current) {
            return;
          }

          if (timing) {
            const seekTo = Math.max(
              0,
              Math.min(
                timing.start,
                Number.isFinite(audio.duration)
                  ? Math.max(0, audio.duration - 0.05)
                  : timing.start,
              ),
            );

            try {
              audio.currentTime = seekTo;
            } catch {
              // Ignore.
            }

            activeTimingRef.current = timing;
            setPlayingAyahIndex(index);
          } else {
            // ئەگەر قارییەکە داتای تایمی نەبوو، دەنگەکە لێبدە بەبێ هیچ هایلایتێک
            activeTimingRef.current = null;
            setPlayingAyahIndex(null);

            try {
              audio.currentTime = 0;
            } catch {
              // Ignore.
            }
          }

          announceAudioPlaying(audio);
          await audio.play();

          if (requestId !== playRequestRef.current) {
            audio.pause();
            return;
          }

          setIsPlaying(true);
        } catch (err) {
          if (requestId !== playRequestRef.current) {
            return;
          }

          activeTimingRef.current = null;
          setPlayingAyahIndex(null);
          setIsPlaying(false);

          setError(
            err instanceof Error
              ? err.message
              : 'دەنگەکە نەکرا پخش بکرێت.',
          );
        } finally {
          if (requestId === playRequestRef.current) {
            loadingPlayRef.current = false;
            setIsLoading(false);
          }
        }
      },
      [
        ayahs,
        selectedReciter,
        selectedSurahNumber,
        timingForCurrentSurah,
        waitForMetadata,
        announceAudioPlaying,
      ],
    );

  const stopAudio =
    useCallback(() => {
      ++playRequestRef.current;
      loadingPlayRef.current = false;
      activeTimingRef.current = null;

      const audio = audioRef.current;
      if (audio) {
        audio.pause();
        try {
          audio.currentTime = 0;
        } catch {
          // Ignore.
        }
      }

      setIsLoading(false);
      setIsPlaying(false);
      setPlayingAyahIndex(null);
    }, []);

  const togglePlayPause =
    useCallback(() => {
      const audio = audioRef.current;
      if (!audio || playingAyahIndex === null) {
        return;
      }

      if (audio.paused) {
        announceAudioPlaying(audio);
        audio
          .play()
          .then(() => setIsPlaying(true))
          .catch(() =>
            setError(
              'دەنگەکە نەکرا پخش بکرێت.',
            ),
          );
      } else {
        audio.pause();
        setIsPlaying(false);
      }
    }, [
      announceAudioPlaying,
      playingAyahIndex,
    ]);

  const handleTimeUpdate =
    useCallback(() => {
      const audio = audioRef.current;
      const activeTiming =
        activeTimingRef.current;

      // ئەگەر تایم نەبوو، ڕێگری لە هیچ گۆڕانکارییەکی هایلایت دەکەین
      if (!audio || !activeTiming) {
        return;
      }

      const now = audio.currentTime;
      const end = Math.max(
        activeTiming.end,
        activeTiming.start + 0.05,
      );

      if (now >= end - 0.02) {
        audio.pause();
        setIsPlaying(false);

        const currentIndex =
          playingAyahIndex;
        if (
          currentIndex === null ||
          currentIndex < 0
        ) {
          activeTimingRef.current = null;
          return;
        }

        const nextIndex =
          currentIndex + 1;

        if (nextIndex < ayahs.length) {
          const nextAyahNumber = Number(
            ayahs[nextIndex]?.ayah ??
              ayahs[nextIndex]?.numberInSurah ??
              nextIndex + 1,
          );

          const nextTiming = timingRows.find(
            (row) =>
              row.ayah === nextAyahNumber,
          );

          if (nextTiming) {
            activeTimingRef.current =
              nextTiming;
            setPlayingAyahIndex(nextIndex);

            try {
              audio.currentTime = Math.max(
                0,
                nextTiming.start,
              );
            } catch {
              // Ignore.
            }

            announceAudioPlaying(audio);
            audio
              .play()
              .then(() => setIsPlaying(true))
              .catch(() =>
                setError(
                  'دەنگەکە نەکرا بەردەوام بکرێت.',
                ),
              );
            return;
          }
        }

        activeTimingRef.current = null;
        setPlayingAyahIndex(null);
        return;
      }

      if (
        playingAyahIndex === null ||
        !ayahs.length ||
        !timingRows.length
      ) {
        return;
      }

      const index =
        getCurrentPageAyahIndex(
          now,
          timingRows,
          ayahs,
        );

      if (
        index >= 0 &&
        index !== playingAyahIndex
      ) {
        setPlayingAyahIndex(index);
      }
    }, [
      announceAudioPlaying,
      ayahs,
      getCurrentPageAyahIndex,
      playingAyahIndex,
      timingRows,
    ]);

  const handleEnded =
    useCallback(() => {
      activeTimingRef.current = null;
      loadingPlayRef.current = false;
      setPlayingAyahIndex(null);
      setIsPlaying(false);
      setIsLoading(false);
    }, []);

  const renderAyahAreas =
    useCallback(() => {
      if (!ayahs.length) {
        return null;
      }

      const topStart = 14;
      const bottomEnd = 92;
      const available =
        bottomEnd - topStart;
      const rowHeight =
        available / ayahs.length;

      return ayahs.map(
        (ayah, index) => {
          const active =
            playingAyahIndex ===
            index;

          const top =
            topStart +
            index * rowHeight;

          return (
            <button
              key={`ayah-${currentPage}-${index}`}
              type="button"
              aria-label={`ئایەت ${
                Number(
                  ayah?.ayah ??
                    ayah?.numberInSurah ??
                    index + 1,
                )
              }`}
              onClick={() =>
                playAyah(index)
              }
              style={{
                position: 'absolute',
                left: '5%',
                right: '5%',
                top: `${top}%`,
                height: `${Math.max(
                  1.2,
                  rowHeight - 0.2,
                )}%`,
                padding: 0,
                margin: 0,
                border: active
                  ? '2px solid rgba(255,174,0,0.9)'
                  : '1px solid transparent',
                borderRadius: 8,
                background: active
                  ? 'rgba(255,196,0,0.26)'
                  : 'transparent',
                boxShadow: active
                  ? '0 0 14px rgba(255,174,0,0.22)'
                  : 'none',
                cursor: 'pointer',
                zIndex: 20,
                appearance: 'none',
                WebkitAppearance:
                  'none',
              }}
            />
          );
        },
      );
    }, [
      ayahs,
      currentPage,
      playAyah,
      playingAyahIndex,
    ]);

  const handleReciterChange =
    useCallback(
      (
        event: React.ChangeEvent<HTMLSelectElement>,
      ) => {
        const id =
          event.target.value;

        const found =
          reciters.find(
            (item) =>
              item.id === id,
          ) ?? null;

        setSelectedReciter(
          found,
        );
      },
      [reciters],
    );

  const handlePageClick =
    useCallback(
      (
        page: number,
      ) => {
        if (page === currentPage) {
          return;
        }

        if (onJumpToPage) {
          onJumpToPage(page);
        } else if (
          page > currentPage
        ) {
          onNextPage();
        } else {
          onPrevPage();
        }
      },
      [
        currentPage,
        onJumpToPage,
        onNextPage,
        onPrevPage,
      ],
    );

  const pages = useMemo(
    () =>
      Array.from(
        {
          length: PAGE_COUNT,
        },
        (_, index) =>
          PAGE_COUNT - index,
      ),
    [],
  );

  return (
    <div
      dir="rtl"
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        background:
          bgStyle?.background ??
          '#fff',
        color: '#111',
        fontFamily:
          'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        ...bgStyle,
      }}
    >
      <audio
        ref={audioRef}
        preload="auto"
        onTimeUpdate={
          handleTimeUpdate
        }
        onEnded={handleEnded}
        onPlay={() =>
          setIsPlaying(true)
        }
        onPause={() =>
          setIsPlaying(false)
        }
        onError={() =>
          setError(
            'فایلە دەنگییەکە نەدۆزرایەوە یان سێرڤەر ڕێگەی پخشکردنی نەدا.',
          )
        }
      />

      <div
        style={{
          position: 'absolute',
          top: 10,
          left: 10,
          right: 10,
          zIndex: 100,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          padding: '8px 10px',
          borderRadius: 16,
          background:
            'rgba(255,255,255,0.92)',
          boxShadow:
            '0 4px 18px rgba(0,0,0,0.10)',
          backdropFilter:
            'blur(12px)',
        }}
      >
        <button
          type="button"
          onClick={onBackToIndex}
          style={{
            border: 'none',
            borderRadius: 10,
            padding: '9px 11px',
            background: '#222',
            color: '#fff',
            cursor: 'pointer',
            fontSize: 13,
            flexShrink: 0,
          }}
        >
          فهرست
        </button>

        <div
          style={{
            flex: 1,
            textAlign: 'center',
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          لاپەڕە {currentPage}
        </div>

        <select
          value={
            selectedReciter?.id ??
            ''
          }
          onChange={
            handleReciterChange
          }
          disabled={!reciters.length}
          style={{
            maxWidth: 190,
            minWidth: 110,
            border: '1px solid #ddd',
            borderRadius: 10,
            padding: '8px 9px',
            background: '#fff',
            color: '#222',
            outline: 'none',
            fontSize: 12,
          }}
        >
          {!reciters.length && (
            <option value="">
              قارییەکان...
            </option>
          )}

          {reciters.map(
            (reciter) => (
              <option
                key={reciter.id}
                value={reciter.id}
              >
                {reciter.name} —{' '}
                {reciter.surahTotal}/114
              </option>
            ),
          )}
        </select>
      </div>

      {(error ||
        !availableForCurrentSurah) &&
        selectedReciter && (
          <div
            style={{
              position: 'absolute',
              top: 72,
              left: 12,
              right: 12,
              zIndex: 95,
              padding:
                '9px 12px',
              borderRadius: 12,
              background: error
                ? 'rgba(180,30,30,0.94)'
                : 'rgba(30,30,30,0.88)',
              color: '#fff',
              textAlign: 'center',
              fontSize: 12,
              lineHeight: 1.5,
            }}
          >
            {error ??
              `سۆرەتی ${selectedSurahNumber} لەلایەن ${selectedReciter.name} بەردەست نییە.`}
          </div>
        )}

      <div
        ref={pagesRef}
        style={{
          position: 'absolute',
          inset: 0,
          overflowX: 'auto',
          overflowY: 'hidden',
          display: 'flex',
          flexDirection: 'row',
          gap: 12,
          padding:
            '90px 8px 110px',
          scrollSnapType:
            'x mandatory',
          WebkitOverflowScrolling:
            'touch',
        }}
      >
        {pages.map(
          (page) => {
            const active =
              page === currentPage;

            return (
              <div
                key={page}
                onClick={() =>
                  handlePageClick(
                    page,
                  )
                }
                style={{
                  position: 'relative',
                  flex:
                    '0 0 min(92vw, 520px)',
                  height:
                    'calc(100vh - 200px)',
                  scrollSnapAlign:
                    'center',
                  borderRadius: 8,
                  background:
                    '#fff',
                  overflow: 'hidden',
                  opacity: active
                    ? 1
                    : 0.45,
                  transform: active
                    ? 'scale(1)'
                    : 'scale(0.97)',
                  transition:
                    'opacity .2s ease, transform .2s ease',
                  boxShadow:
                    active
                      ? '0 8px 28px rgba(0,0,0,0.14)'
                      : '0 2px 10px rgba(0,0,0,0.05)',
                  cursor:
                    active
                      ? 'default'
                      : 'pointer',
                }}
              >
                <img
                  src={pageImgUrl(
                    page,
                  )}
                  alt={`Quran page ${page}`}
                  draggable={false}
                  style={{
                    position:
                      'absolute',
                    inset: 0,
                    width: '100%',
                    height: '100%',
                    objectFit:
                      'contain',
                    userSelect:
                      'none',
                    WebkitUserDrag:
                      'none',
                    pointerEvents:
                      'none',
                    filter:
                      'grayscale(100%) contrast(115%) brightness(102%)',
                    mixBlendMode:
                      'multiply',
                  }}
                />

                {active &&
                  renderAyahAreas()}

                {active &&
                  isLoading && (
                    <div
                      style={{
                        position:
                          'absolute',
                        top: '50%',
                        left: '50%',
                        transform:
                          'translate(-50%, -50%)',
                        zIndex: 60,
                        padding:
                          '9px 13px',
                        borderRadius: 12,
                        background:
                          'rgba(0,0,0,0.72)',
                        color: '#fff',
                        fontSize: 12,
                      }}
                    >
                      دەنگ بار دەکرێت...
                    </div>
                  )}

                {active &&
                  showNumbers && (
                    <div
                      style={{
                        position:
                          'absolute',
                        bottom: 8,
                        left: '50%',
                        transform:
                          'translateX(-50%)',
                        zIndex: 80,
                        minWidth: 38,
                        textAlign:
                          'center',
                        padding:
                          '5px 9px',
                        borderRadius: 999,
                        background:
                          'rgba(255,255,255,0.9)',
                        boxShadow:
                          '0 2px 8px rgba(0,0,0,0.12)',
                        fontSize: 11,
                        fontWeight: 700,
                      }}
                    >
                      {page}
                    </div>
                  )}
              </div>
            );
          },
        )}
      </div>

      <div
        style={{
          position: 'absolute',
          bottom: 10,
          left: 10,
          right: 10,
          zIndex: 110,
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          padding: '9px 10px',
          borderRadius: 16,
          background:
            'rgba(255,255,255,0.95)',
          boxShadow:
            '0 -3px 18px rgba(0,0,0,0.12)',
          backdropFilter:
            'blur(12px)',
        }}
      >
        <button
          type="button"
          onClick={
            togglePlayPause
          }
          disabled={
            playingAyahIndex ===
              null ||
            isLoading
          }
          style={{
            width: 42,
            height: 42,
            border: 'none',
            borderRadius: 12,
            background:
              '#222',
            color: '#fff',
            cursor: 'pointer',
            fontSize: 17,
            flexShrink: 0,
            opacity:
              playingAyahIndex ===
                null ||
              isLoading
                ? 0.5
                : 1,
          }}
        >
          {isPlaying
            ? 'Ⅱ'
            : '▶'}
        </button>

        <button
          type="button"
          onClick={stopAudio}
          style={{
            width: 42,
            height: 42,
            border: '1px solid #ddd',
            borderRadius: 12,
            background: '#fff',
            color: '#222',
            cursor: 'pointer',
            fontSize: 15,
            flexShrink: 0,
          }}
        >
          ■
        </button>

        <div
          style={{
            flex: 1,
            minWidth: 0,
            textAlign: 'right',
          }}
        >
          <div
            style={{
              fontSize: 12,
              fontWeight: 700,
              whiteSpace:
                'nowrap',
              overflow:
                'hidden',
              textOverflow:
                'ellipsis',
            }}
          >
            {selectedReciter?.name ??
              'قاری'}
          </div>

          <div
            style={{
              marginTop: 3,
              fontSize: 11,
              color: '#777',
            }}
          >
            {playingAyahIndex !==
            null
              ? `ئایەت ${
                  playingAyahIndex +
                  1
                }`
              : 'ئایەتێک هەڵبژێرە'}
          </div>
        </div>

        <button
          type="button"
          onClick={() =>
            onPrevPage()
          }
          disabled={
            currentPage <= 1
          }
          style={{
            border: '1px solid #ddd',
            borderRadius: 10,
            padding:
              '8px 10px',
            background: '#fff',
            cursor: 'pointer',
            opacity:
              currentPage <= 1
                ? 0.4
                : 1,
          }}
        >
          →
        </button>

        <button
          type="button"
          onClick={() =>
            onNextPage()
          }
          disabled={
            currentPage >=
            PAGE_COUNT
          }
          style={{
            border: '1px solid #ddd',
            borderRadius: 10,
            padding:
              '8px 10px',
            background: '#fff',
            cursor: 'pointer',
            opacity:
              currentPage >=
              PAGE_COUNT
                ? 0.4
                : 1,
          }}
        >
          ←
        </button>
      </div>
    </div>
  );
}

export default QuranReader;
